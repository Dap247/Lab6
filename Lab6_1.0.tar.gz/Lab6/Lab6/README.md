# Lab6
 The knapsack problem
