library(testthat)
library(Lab6)

test_check("Lab6")
